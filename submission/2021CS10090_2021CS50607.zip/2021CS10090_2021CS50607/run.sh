chmod 777 test
rm -f solved_alarm.bif
./test $1 $2