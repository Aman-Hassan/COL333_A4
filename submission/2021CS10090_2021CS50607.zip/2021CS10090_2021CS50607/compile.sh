g++ -std=c++11 -O3 -funroll-loops -flto -march=native test.cpp -o test
